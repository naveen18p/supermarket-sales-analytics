# Supermarket Sales Dashboard — Project Brief

## Scenario
You are a Data Analyst at FreshMart, a fictional multi-city supermarket chain in India.
Management wants to understand sales, profit, customer behavior, product performance,
store performance, returns, and monthly target achievement.

## Your job
1. Load and inspect the raw CSV files in SQL.
2. Identify and fix data-quality problems.
3. Write SQL analysis queries.
4. Build a clean Power BI data model.
5. Create DAX measures and dashboard pages.
6. Present business insights and recommendations.

## Important
This is intentionally messy synthetic business data. Do not present it as real FreshMart
company data. Investigate duplicates, blanks, invalid IDs, unusual numeric values, and
relationship problems before analysis.

## Core business questions
- Total net sales, profit, profit margin, transactions, customers
- Monthly sales/profit trends
- Best/worst stores, regions, categories and products
- Top customers and average basket value
- Store target achievement
- Return rate and major return reasons
- Business recommendations
